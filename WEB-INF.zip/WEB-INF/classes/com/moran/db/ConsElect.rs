datos.ConsElect
