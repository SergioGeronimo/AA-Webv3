datos.Factor
